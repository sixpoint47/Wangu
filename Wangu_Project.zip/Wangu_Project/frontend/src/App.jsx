import React, { useEffect, useState } from 'react';

const App = () => {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    fetch('http://localhost:5000/api/users')
      .then(res => res.json())
      .then(data => setUsers(data));
  }, []);

  return (
    <div>
      <h1>Welcome to Wangu</h1>
      <ul>
        {users.map(user => (
          <li key={user._id}>{user.name} ({user.age}) - {user.gender}</li>
        ))}
      </ul>
    </div>
  );
};

export default App;